
Plugin Calculator for FAR Manager (c) Igor Russkih 1998-2001
                                  (c) uncle-vunkis 2009-2012
                                  (c) FarPlugins Team 2020
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
https://github.com/FarPlugins/Calculator

How you can install this plugin?

1.  Create subdirectory \Far\PlugIns\Calculator
    and copy there all calculator files.
2.  Restart FAR Manager and Calculator is ready for work:
    F11 (plugins Menu) - Calculator.

License - BSD 3-Clause License
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Плагин заменит ваш ручной калькулятор, если у того подсядут
батарейки. Ну, может еще и поболе того.

Как заставить этого хрена работать?

1. Создайте каталог Far\Plugins\calculator
2. Киньте туда все файлы калькулятора с сохранением путей.
2. Перезапустите FAR, и Калькулятор готов к работе:
   F11(Меню плагиновов) - Калькулятор(Calculator)

Лицензия - BSD 3-Clause License
