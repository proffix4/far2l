#pragma once
bool TTYNegotiateFar2l(int fdin, int fdout, bool enable);
