#ifndef _COLORER_COLORER_H_
#define _COLORER_COLORER_H_

#include <memory>

class Colorer
{
public:

  ~Colorer();
  Colorer();

private:

  void initColorer();

};

#endif //_COLORER_COLORER_H_

